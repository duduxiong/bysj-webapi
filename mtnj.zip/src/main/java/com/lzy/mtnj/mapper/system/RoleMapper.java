package com.lzy.mtnj.mapper.system;

import com.lzy.mtnj.model.Role;
import org.springframework.stereotype.Repository;
import tk.mybatis.mapper.common.Mapper;

@Repository
public interface RoleMapper extends Mapper<Role> {
}
