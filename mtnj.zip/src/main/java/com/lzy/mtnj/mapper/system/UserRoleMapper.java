package com.lzy.mtnj.mapper.system;

import com.lzy.mtnj.model.UserRole;
import tk.mybatis.mapper.common.Mapper;

public interface UserRoleMapper extends Mapper<UserRole> {
}
