package com.lzy.mtnj.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class CountResult {
    private String id;
    private String userName;
    private String num;
}
