package com.lzy.mtnj.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReqDelIds {
    int[]ids;
}
