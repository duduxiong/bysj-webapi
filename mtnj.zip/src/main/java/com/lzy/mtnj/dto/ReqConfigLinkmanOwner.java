package com.lzy.mtnj.dto;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ReqConfigLinkmanOwner {
    private Integer[]ids;
    private String newOwnerId;
}
