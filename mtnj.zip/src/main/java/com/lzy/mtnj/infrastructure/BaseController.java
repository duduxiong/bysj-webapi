package com.lzy.mtnj.infrastructure;

public abstract class BaseController extends Base {
}
