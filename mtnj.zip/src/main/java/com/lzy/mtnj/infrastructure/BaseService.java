package com.lzy.mtnj.infrastructure;

import com.alibaba.fastjson.JSON;
import com.lzy.mtnj.model.user.User;
import org.apache.shiro.SecurityUtils;
import org.ehcache.Cache;
import org.ehcache.CacheManager;
import org.springframework.beans.factory.annotation.Autowired;

public abstract class BaseService extends Base {

}
